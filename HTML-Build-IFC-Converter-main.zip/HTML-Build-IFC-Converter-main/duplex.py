import HTMLBuild as hb

hb.modelLoader("duplex")